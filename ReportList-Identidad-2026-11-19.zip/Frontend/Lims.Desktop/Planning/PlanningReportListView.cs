using System.Globalization;
using Lims.Contracts.Planning;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Automation;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Markup;
using Windows.ApplicationModel.DataTransfer;
using Windows.System;

namespace Lims.Desktop.Planning;

public sealed class PlanningReportListView : UserControl,IDisposable
{
    private readonly PlanningApiClient _api;
    private readonly Func<IReadOnlyList<string>> _permissions;
    private readonly Func<Guid,Task> _dossier;
    private readonly Func<bool> _administrator;
    private readonly TextBox _search=PlanningUi.Field("JOB / búsqueda múltiple",max:20000);
    private readonly TextBox _test=PlanningUi.Field("Prueba de Planificación");
    private readonly TextBox _lab=PlanningUi.Field("Laboratorio");
    private readonly TextBox _service=PlanningUi.Field("Servicio");
    private readonly TextBox _buyer=PlanningUi.Field("Buyer");
    private readonly TextBox _scan=PlanningUi.Field("Escáner · código AR",max:200);
    private readonly ComboBox _view=new(){Header="Vista",ItemsSource=new[]{"Pendientes","Completadas","Activas","Archivadas","Todas"},SelectedIndex=0,MinWidth=145};
    private readonly ListView _list=new(){SelectionMode=ListViewSelectionMode.Multiple,HorizontalContentAlignment=HorizontalAlignment.Stretch};
    private readonly TextBlock _status=PlanningUi.Text("",12,true);
    private readonly TextBlock _result=PlanningUi.Text("",13);
    private readonly StackPanel _actions=PlanningUi.Stack();
    private readonly Button _previous;
    private readonly Button _next;
    private CancellationTokenSource _lifetime=new();
    private int _page=1,_total;
    private bool _loading;
    private bool _reload;
    public event Func<Task>? Changed;
    public PlanningReportListView(PlanningApiClient api,Func<Guid,Task> dossier,Func<IReadOnlyList<string>> permissions,Func<bool> administrator)
    {
        _api=api;_permissions=permissions;_dossier=dossier;_administrator=administrator;
        AutomationProperties.SetName(_search,"Buscar JOB en Report List");AutomationProperties.SetName(_list,"Ejecuciones de Report List");AutomationProperties.SetName(_scan,"Código AR de Report List");
        var find=PlanningUi.Button("Buscar Report List",async()=>{_page=1;await Load();});
        var refresh=PlanningUi.Button("Actualizar Report List",Load);
        _previous=PlanningUi.Button("Anterior Report List",async()=>{if(_page>1)_page--;await Load();});
        _next=PlanningUi.Button("Siguiente Report List",async()=>{if(_page*100<_total)_page++;await Load();});
        _search.KeyDown+=async(_,e)=>{if(e.Key==VirtualKey.Enter){e.Handled=true;_page=1;await Load();}};
        _scan.KeyDown+=async(_,e)=>{if(e.Key==VirtualKey.Enter){e.Handled=true;await Scan();}};
        _view.SelectionChanged+=async(_,_)=>{_page=1;if(IsLoaded)await Load();};
        _list.ItemTemplate=(DataTemplate)XamlReader.Load("""
            <DataTemplate xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation">
              <StackPanel Spacing="4" Padding="8">
                <StackPanel Orientation="Horizontal" Spacing="18">
                  <TextBlock Text="{Binding Execution.Job}" Width="220" FontWeight="SemiBold"/>
                  <TextBlock Text="{Binding Execution.PlanningTest}" Width="280" TextTrimming="CharacterEllipsis"/>
                  <TextBlock Text="{Binding Execution.Laboratory}" Width="110"/>
                  <TextBlock Text="{Binding Execution.DigitizationState}" Width="150"/>
                  <TextBlock Text="{Binding Execution.DigitizedBy}" Width="190"/>
                </StackPanel>
                <StackPanel Orientation="Horizontal" Spacing="14" Opacity="0.75">
                  <TextBlock Text="{Binding Execution.OriginalTest}" Width="330"/>
                  <TextBlock Text="{Binding Execution.ExecutionId}" Width="290"/>
                  <TextBlock Text="{Binding CheckMode}" Width="65"/>
                  <TextBlock Text="{Binding CheckedAtText}" Width="165"/>
                  <TextBlock Text="{Binding BlockLabel}" Width="90"/>
                </StackPanel>
                <StackPanel Orientation="Horizontal" Spacing="14" Opacity="0.75">
                  <TextBlock Text="Mantener en programación:"/><TextBlock Text="{Binding KeepLabel}"/>
                  <TextBlock Text="Archivada:"/><TextBlock Text="{Binding ArchivedLabel}"/>
                </StackPanel>
              </StackPanel>
            </DataTemplate>
            """);
        var header=PlanningUi.Stack(PlanningUi.Text("Report List / Digitación",24),
            PlanningUi.Text("Selecciona ejecuciones individuales. Los marcados conservan usuario, hora, bloque e historial en el expediente.",12,true),
            PlanningUi.Row(_search,_view,find,refresh),PlanningUi.Row(_test,_lab,_service,_buyer),_actions,
            PlanningUi.Text("JOB · Prueba · Laboratorio · Estado · Usuario / Nombre técnico · Ejecución · Modo · Fecha y hora · Bloque",12,true),_result);
        var layout=PlanningUi.Rows(GridLength.Auto,new(1,GridUnitType.Star),GridLength.Auto);
        PlanningUi.Place(layout,header,0);PlanningUi.Place(layout,new ScrollViewer{HorizontalScrollBarVisibility=ScrollBarVisibility.Auto,HorizontalScrollMode=ScrollMode.Enabled,VerticalScrollMode=ScrollMode.Disabled,Content=_list},1);
        PlanningUi.Place(layout,PlanningUi.Row(_previous,_next,_status),2);Content=layout;
        Unloaded+=(_,_)=>_lifetime.Cancel();
    }
    private bool Has(string permission)=>_permissions().Contains(permission,StringComparer.Ordinal);
    private ReportListItem[] Selected()=>_list.SelectedItems.OfType<ReportListItem>().ToArray();
    public async Task Load()
    {
        if(_loading){_reload=true;return;}if(_lifetime.IsCancellationRequested){_lifetime.Dispose();_lifetime=new();}
        _loading=true;_status.Text="Cargando Report List…";
        _list.ItemsSource=null;
        try
        {
            var response=await _api.ReportList(new(_search.Text,_view.SelectedIndex switch{1=>"Checked",2=>"Active",3=>"Archived",4=>"All",_=>"Pending"},_lab.Text,_test.Text,_service.Text,_buyer.Text,_page),_lifetime.Token);
            if(!response.IsSuccess||response.Value is not {} page){_list.ItemsSource=null;_status.Text=response.Error??"No se pudo consultar Report List.";return;}
            _total=page.Total;_list.ItemsSource=page.Items;_status.Text=$"Página {_page} · {page.Total:N0} ejecuciones · Hora de Guatemala (UTC−6)";
            _previous.IsEnabled=_page>1;_next.IsEnabled=_page*100<_total;BuildActions();
        }
        catch(OperationCanceledException){ }
        finally{_loading=false;}
        if(_reload&&!_lifetime.IsCancellationRequested){_reload=false;await Load();}
    }
    private void BuildActions()
    {
        if(_scan.Parent is Panel parent)parent.Children.Remove(_scan);
        _actions.Children.Clear();
        var selection=PlanningUi.Row();var marking=PlanningUi.Row();_actions.Children.Add(selection);_actions.Children.Add(marking);
        selection.Children.Add(PlanningUi.Button("Seleccionar página",()=>{_list.SelectAll();return Task.CompletedTask;}));
        selection.Children.Add(PlanningUi.Button("Limpiar selección",()=>{_list.SelectedItems.Clear();return Task.CompletedTask;}));
        selection.Children.Add(PlanningUi.Button("Expediente de ejecución",()=>Selected().FirstOrDefault() is {} item?_dossier(item.Execution.EpisodeId):Task.CompletedTask));
        selection.Children.Add(PlanningUi.Button("Copiar Report List",()=>{var data=new DataPackage();data.SetText(string.Join('\n',Selected().Select(x=>$"{x.Execution.Job}\t{x.Execution.PlanningTest}\t{x.Execution.OriginalTest}\t{x.Execution.ExecutionId}\t{x.Execution.DigitizationState}\t{x.Execution.DigitizedBy}\t{x.Execution.DigitizedAt:O}\t{x.BlockNumber}")));Clipboard.SetContent(data);return Task.CompletedTask;}));
        if(Has(PlanningPermissions.ReportMark))
        {
            marking.Children.Add(PlanningUi.Button("Marcar seleccionadas",()=>Check(true),true));
            marking.Children.Add(_scan);
        }
        if(Has(PlanningPermissions.ReportReview))
        {
            marking.Children.Add(PlanningUi.Button("Corregir marcado",()=>Check(false)));
            marking.Children.Add(PlanningUi.Button("Mantener / archivar",Keep));
        }
    }
    private async Task Check(bool check)
    {
        var selected=Selected();if(selected.Length==0){_result.Text="Selecciona una o varias ejecuciones.";return;}
        var reason=PlanningUi.Field("Motivo obligatorio",max:1000);
        var modeOverride=new CheckBox{Content="Excepción administrativa del modo de marcado"};
        var content=PlanningUi.Stack(PlanningUi.Text(string.Join('\n',selected.Select(x=>$"{x.Execution.Job} · {x.Execution.PlanningTest} · {x.Execution.ExecutionId}")),12),reason);
        if(_administrator())content.Children.Add(modeOverride);
        var dialog=new ContentDialog{XamlRoot=XamlRoot,Title=check?$"Marcar {selected.Length} ejecuciones":"Desmarcar y restaurar ejecuciones",Content=content,PrimaryButtonText="Guardar marcado",CloseButtonText="Cancelar",DefaultButton=ContentDialogButton.Close};
        if(await dialog.ShowAsync()!=ContentDialogResult.Primary)return;
        var response=await _api.CheckReport(new(selected.Select(x=>new ReportExecutionVersion(x.Execution.ExecutionId!.Value,x.Version)).ToArray(),check,reason.Text,modeOverride.IsChecked==true),!check||modeOverride.IsChecked==true,_lifetime.Token);
        if(!response.IsSuccess){_result.Text=response.Error;return;}
        _result.Text=response.Value?.ReadyJobs.Count>0?"Última prueba pendiente completada: "+string.Join(", ",response.Value.ReadyJobs):"Marcado guardado en el historial.";
        await Load();if(Changed is {} changed)await changed();
    }
    private async Task Keep()
    {
        var selected=Selected();if(selected.Length!=1){_result.Text="Selecciona una ejecución para cambiar su permanencia.";return;}
        var item=selected[0];var keep=new CheckBox{Content="Mantener en programación",IsChecked=item.KeepInPlanning};var reason=PlanningUi.Field("Motivo obligatorio",max:1000);
        var dialog=new ContentDialog{XamlRoot=XamlRoot,Title=item.Execution.Job+" · "+item.Execution.PlanningTest,Content=PlanningUi.Stack(keep,reason),PrimaryButtonText="Guardar permanencia",CloseButtonText="Cancelar"};
        if(await dialog.ShowAsync()!=ContentDialogResult.Primary)return;
        var response=await _api.KeepReport(new(new(item.Execution.ExecutionId!.Value,item.Version),keep.IsChecked==true,reason.Text),_lifetime.Token);
        _result.Text=response.IsSuccess?"Permanencia guardada.":response.Error;await Load();
    }
    private async Task Scan()
    {
        if(!Has(PlanningPermissions.ReportMark))return;
        var response=await _api.ScanReport(new(_scan.Text,"Marcado mediante código AR en Report List"),_lifetime.Token);
        _result.Text=response.IsSuccess?"Código verificado y ejecución marcada.":response.Error;
        if(response.IsSuccess){_scan.Text="";await Load();if(Changed is {} changed)await changed();}
    }
    public void Clear(){_lifetime.Cancel();_list.ItemsSource=null;_search.Text="";_scan.Text="";_result.Text="";}
    public void Dispose(){Clear();_lifetime.Dispose();}
}
