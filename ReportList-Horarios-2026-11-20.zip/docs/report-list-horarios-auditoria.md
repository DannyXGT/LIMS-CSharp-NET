# Report List: auditoría previa y decisiones

20 de noviembre de 2026. Inspección de código, antes de modificar comportamiento o base.

- El host existente es **WinUI 3**, no WPF. Se conserva AppShell, JWT, permisos y PostgreSQL.
- Referencias visuales: `ReferenceMaterialsPage.xaml`, `PreparationsPage.xaml`, `CommercialPreparationDetailDialog.cs`, `LimsTabStrip`, `Motion` y recursos `Lims*` existentes.
- Flujo vigente: `PlanningReportListView`, `ReportListGrid`, `PlanningApiClient`, `PlanningEndpoints`, `PostgresReportList` y contratos `ReportListContracts`.
- `planning.executions.id` identifica la ejecución. JOB y equivalencia no son únicos. `original_test`, `equivalence`, `execution_type`, episodio y procedencia se conservan.
- `digitized_at`, `tested_on`, `digitized_by` representan la digitación. `report_checks.checked_at` y `actor_id` **también representan el marcado anterior**, no una revisión posterior. No se renombrarán ni reinterpretarán.
- `report_blocks.number` es una secuencia que se reutiliza por actor durante 15 minutos de tiempo del servidor. No representa `horario` ni `fecha_prueba`. Se conserva sin convertirlo.
- `report_close_alerts` señala última pendiente completada entre registros conocidos; no acredita universo TIPS ni cierre oficial.
- `Digitacion_23_OCT.html` inspeccionado en `Desktop/programas/App_web`: `toggleRow` selecciona temporalmente; `abrirConfirmacion` revisa selección; confirmación asigna `h`, `f`, `dp` y reinicia `chk`; `checkGroups` agrupa fecha+hora; `computeCierres` evalúa todas las filas cargadas. Se traslada la operación, sin localStorage, eliminación de duplicados ni exportación/importación para sincronizar Consulta.
- `Desktop/programas/Analisis_App_web.md` confirma que las tablas de Consulta y Digitación históricas estaban separadas y que sus cierres podían depender del subconjunto local.
- El Report List React anterior usa `checked_at`, `prueba_completa`, bloques y modo manual/escáner. No contiene una revisión posterior equivalente al `chequeado` del HTML.

## Diseño de persistencia aditiva

Sesión UUID por confirmación, fecha/hora operativa explícita, actor del servidor y fecha de guardado distinta. Miembros inmutables con versión de digitación; revisión posterior por otro evento con actor, fecha y revisión. Reintento de la misma solicitud no duplica sesión. Correcciones o cambios de versión invalidan el chequeo del grupo; no se trasladan a otra ejecución ni a otra hora. Registros antiguos sin sesión permanecen históricos, sin asignarles una sesión u hora inventada.

Consulta comparte las mismas ejecuciones y expone el chequeo derivado de la sesión válida. Cierres calcula sobre todos los episodios del JOB, excluye NO PROGRAMAR explícito, retenciones, equivalencias faltantes, incidentes y filas de Report List sin conciliar; informa que la cobertura es la persistida y no certifica cobertura externa completa.

## Límites de validación

Solo se autoriza la copia restaurada local `127.0.0.1:55441/lims_planning_dev` y bases efímeras de pruebas. Ninguna migración o cambio en producción. Capturas, persistencia, concurrencia y rendimiento deben documentarse después de ejecutar; este archivo no acredita esos resultados.
