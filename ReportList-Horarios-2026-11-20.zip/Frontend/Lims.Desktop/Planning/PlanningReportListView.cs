using System.Collections.ObjectModel;
using System.Globalization;
using Lims.Contracts.Planning;
using Lims.DesignSystem.Controls;
using Lims.DesignSystem.Presentation;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Automation;
using Microsoft.UI.Xaml.Controls;
using Windows.ApplicationModel.DataTransfer;
using Windows.System;

namespace Lims.Desktop.Planning;

public sealed class PlanningReportListView : UserControl,IDisposable
{
    private readonly PlanningApiClient _api;
    private readonly Func<IReadOnlyList<string>> _permissions;
    private readonly Func<Guid,Task> _dossier;
    private readonly Func<bool> _administrator;
    private readonly TextBox _search=PlanningUi.Field("",max:20000),_scan=PlanningUi.Field("",max:200);
    private readonly TextBox _test=PlanningUi.Field("Prueba de Planificación"),_lab=PlanningUi.Field("Laboratorio"),_service=PlanningUi.Field("Servicio"),_buyer=PlanningUi.Field("Cliente / Buyer");
    private readonly TextBox _clockDate=PlanningUi.Field("",DateTimeOffset.UtcNow.ToOffset(TimeSpan.FromHours(-6)).ToString("yyyy-MM-dd",CultureInfo.InvariantCulture),10);
    private readonly TextBox _clockTime=PlanningUi.Field("",DateTimeOffset.UtcNow.ToOffset(TimeSpan.FromHours(-6)).ToString("HH:mm",CultureInfo.InvariantCulture),5);
    private readonly ComboBox _view=new(){ItemsSource=new[]{"Pendientes","Digitadas","Todas"},SelectedIndex=0,MinWidth=135,Style=(Style)Application.Current.Resources["LimsCompactComboBoxStyle"]};
    private readonly ComboBox _scheduleState=new(){ItemsSource=new[]{"Todos los horarios","Pendientes","Chequeados","Con excepciones"},SelectedIndex=0,MinWidth=170,Style=(Style)Application.Current.Resources["LimsCompactComboBoxStyle"]};
    private readonly LimsTabStrip _tabs=new();
    private readonly ReportListGrid _grid=new();
    private readonly TextBlock _status=PlanningUi.Text("",12,true),_result=PlanningUi.Text("",12),_connection=PlanningUi.Text("Conectando…",12,true),_selection=PlanningUi.Text("",12,true);
    private readonly ProgressRing _progress=new(){Width=18,Height=18,IsActive=false};
    private readonly Button _pause,_mark,_correct,_review,_next;
    private readonly StackPanel _scanRow,_intro,_context;
    private readonly Grid _digitization,_schedules,_closures;
    private readonly Border _detail;
    private readonly TextBlock _detailTitle=PlanningUi.Text("",17),_detailMeta=PlanningUi.Text("",12,true),_history=PlanningUi.Text("",12,true);
    private readonly ReportNativeTable<ReportSchedule> _scheduleTable;
    private readonly ReportNativeTable<ReportScheduleMember> _members;
    private readonly ObservableCollection<ReportSchedule> _scheduleRows=[];
    private readonly ObservableCollection<ReportClosure> _closureRows=[];
    private readonly DispatcherTimer _sync=new(){Interval=TimeSpan.FromSeconds(15)};
    private CancellationTokenSource _request=new(),_detailRequest=new();
    private ReportListRows? _rows;
    private ReportScheduleDetail? _opened;
    private ReportDigitization? _retry;
    private string _sort="Default",_verified="";
    private long? _block,_listRevision;private DateOnly? _date;
    private int _page=1,_total;
    private bool _descending,_mutating,_paused=true,_trackingAvailable,_onlyTable,_loading;
    public event Func<Task>? Changed;
    public PlanningReportListView(PlanningApiClient api,Func<Guid,Task> dossier,Func<IReadOnlyList<string>> permissions,Func<bool> administrator)
    {
        _api=api;_permissions=permissions;_dossier=dossier;_administrator=administrator;
        _search.PlaceholderText="Buscar por JOB, prueba o cliente";_search.MinWidth=200;_search.MinHeight=38;
        AutomationProperties.SetName(_search,"Buscar JOB en Report List");AutomationProperties.SetName(_view,"Vista");AutomationProperties.SetName(_scheduleState,"Estado de horarios");
        _clockDate.MinWidth=115;_clockDate.Width=135;_clockDate.PlaceholderText="yyyy-MM-dd";_clockTime.MinWidth=100;_clockTime.Width=105;_clockTime.PlaceholderText="HH:mm";
        AutomationProperties.SetName(_clockDate,"Fecha de digitación");AutomationProperties.SetName(_clockTime,"Hora de digitación");
        _scan.PlaceholderText="Código AR · Enter para registrar";AutomationProperties.SetName(_scan,"Código AR de Report List");
        _search.KeyDown+=async(_,e)=>{if(e.Key==VirtualKey.Enter){e.Handled=true;await Load();}};
        _scan.KeyDown+=async(_,e)=>{if(e.Key==VirtualKey.Enter){e.Handled=true;await Scan();}};
        _view.SelectionChanged+=async(_,_)=>{if(IsLoaded&&_tabs.SelectedIndex==0)await Load();};
        _scheduleState.SelectionChanged+=async(_,_)=>{if(IsLoaded&&_tabs.SelectedIndex==1)await Load();};
        _grid.CanKeep=()=>!_mutating&&Has(PlanningPermissions.ReportReview);_grid.KeepRequested+=Keep;
        _grid.OpenRequested+=item=>_dossier(item.Execution.EpisodeId);_grid.SortRequested+=async key=>{_descending=_sort==key&&!_descending;_sort=key;_grid.SetSort(key,_descending);await Load();};
        _grid.FilterRequested+=ColumnFilter;_grid.SelectionChanged+=UpdateSelection;
        _intro=PlanningUi.Stack(PlanningUi.Text("Report List",23),PlanningUi.Text("Digitación y verificación de pruebas",12,true));_intro.Spacing=1;
        var only=Compact("Solo tabla",()=>{_onlyTable=!_onlyTable;_intro.Visibility=_onlyTable?Visibility.Collapsed:Visibility.Visible;return Task.CompletedTask;});
        only.Click+=(_,_)=>only.Content=_onlyTable?"Mostrar encabezado":"Solo tabla";
        var scanner=PlanningUi.Text("Escáner",12,true);ToolTipService.SetToolTip(scanner,"Conexión física no verificada. Captura AR requiere tracking válido y un lector configurado.");
        var indicators=PlanningUi.Row(_connection,scanner,only);indicators.Spacing=14;indicators.VerticalAlignment=VerticalAlignment.Center;
        var header=ConsultationVisuals.Split(_intro,indicators);
        foreach(var title in new[]{"Digitación","Chequeo de horarios","Cierres"})_tabs.Items.Add(new LimsTabItem{Label=title});
        AutomationProperties.SetName(_tabs,"Vistas de Report List");
        var find=Compact("Buscar",Load);AutomationProperties.SetName(find,"Buscar Report List");
        var refresh=Compact("Actualizar",Load);AutomationProperties.SetName(refresh,"Actualizar Report List");
        var multiple=Compact("Varios JOBs",Multiple);AutomationProperties.SetName(multiple,"Búsqueda múltiple de Report List");
        var filters=Compact("Filtros",()=>Task.CompletedTask);AutomationProperties.SetName(filters,"Filtros de Report List");
        var filterPanel=PlanningUi.Stack(_test,_lab,_service,_buyer);filterPanel.Width=290;
        var filterFlyout=new Flyout{Content=filterPanel};filters.Flyout=filterFlyout;
        filterPanel.Children.Add(Compact("Aplicar filtros",async()=>{filterFlyout.Hide();await Load();}));
        filterPanel.Children.Add(Compact("Limpiar filtros",async()=>{_test.Text=_lab.Text=_service.Text=_buyer.Text=_verified="";_block=null;_date=null;filterFlyout.Hide();await Load();}));
        _pause=Compact("Captura AR",()=>{_paused=!_paused;UpdateScanner();if(!_paused)_scan.Focus(FocusState.Programmatic);return Task.CompletedTask;});_pause.IsEnabled=false;
        ToolTipService.SetToolTip(_pause,"Entrada de códigos AR; no confirma la conexión física de un lector.");
        var tools=PlanningUi.Row(_view,_scheduleState,filters,refresh);tools.Spacing=6;
        var searchBar=new Grid{ColumnSpacing=8};foreach(var width in new[]{new GridLength(1,GridUnitType.Star),GridLength.Auto,GridLength.Auto,GridLength.Auto})searchBar.ColumnDefinitions.Add(new(){Width=width});
        searchBar.Children.Add(_search);Grid.SetColumn(find,1);searchBar.Children.Add(find);Grid.SetColumn(multiple,2);searchBar.Children.Add(multiple);Grid.SetColumn(tools,3);searchBar.Children.Add(tools);
        _mark=Compact("Guardar digitación",SaveDigitization,true,()=>!_mutating&&_grid.Selected.Count is >0 and <=500&&_grid.Selected.All(x=>!x.Execution.Complete&&!x.Execution.NoProgram&&!x.Execution.OnHold&&!string.IsNullOrWhiteSpace(x.Execution.Equivalence)));_correct=Compact("Corregir digitación",Correct);
        var dossierButton=Compact("Expediente / historial",()=>_grid.FirstSelected is {} item?_dossier(item.Execution.EpisodeId):Task.CompletedTask);
        var copy=Compact("Copiar",()=>{var data=new DataPackage();data.SetText("JOB\tPrueba\tLaboratorio\tCliente\tFecha\tHora\tDigitado por\tEjecución\n"+string.Join('\n',_grid.Selected.Select(x=>$"{x.Execution.Job}\t{x.Execution.PlanningTest}\t{x.Execution.Laboratory}\t{x.Execution.Buyer}\t{x.Execution.TestedOn}\t{x.CheckedTimeText}\t{x.Execution.DigitizedBy}\t{x.Execution.ExecutionId}")));Clipboard.SetContent(data);return Task.CompletedTask;});
        var columns=Compact("Columnas",()=>Task.CompletedTask);columns.Flyout=_grid.ColumnsMenu();
        var more=new MenuFlyout();var selectItem=new MenuFlyoutItem{Text="Seleccionar cargadas"};selectItem.Click+=(_,_)=>_grid.SelectAll();more.Items.Add(selectItem);
        var clearItem=new MenuFlyoutItem{Text="Limpiar selección"};clearItem.Click+=(_,_)=>_grid.ClearSelection();more.Items.Add(clearItem);
        var selectionButton=Compact("Selección",()=>Task.CompletedTask);selectionButton.Flyout=more;
        var tableTools=ConsultationVisuals.Split(PlanningUi.Row(selectionButton,columns,_pause),PlanningUi.Row(_correct,dossierButton,copy));
        _context=PlanningUi.Row(_selection,PlanningUi.Text("Fecha",12,true),_clockDate,PlanningUi.Text("Hora",12,true),_clockTime,_mark);_context.Spacing=8;_context.VerticalAlignment=VerticalAlignment.Center;_context.Visibility=Visibility.Collapsed;
        _scanRow=PlanningUi.Row(PlanningUi.Text("Captura AR",12,true),_scan);_scanRow.Visibility=Visibility.Collapsed;_result.Visibility=Visibility.Collapsed;
        var table=new Border{Child=_grid,Background=PlanningUi.Brush("LimsSurfaceBrush"),BorderBrush=PlanningUi.Brush("LimsBorderBrush"),BorderThickness=new(1),CornerRadius=new(6)};
        _digitization=PlanningUi.Rows(GridLength.Auto,GridLength.Auto,new(1,GridUnitType.Star),GridLength.Auto);_digitization.RowSpacing=8;
        PlanningUi.Place(_digitization,tableTools,0);PlanningUi.Place(_digitization,_context,1);PlanningUi.Place(_digitization,table,2);PlanningUi.Place(_digitization,_scanRow,3);
        _scheduleTable=new("Horarios de digitación",[("Fecha",115),("Horario",90),("Pruebas",75),("JOBs",70),("Digitado por",190),("Chequeo",165)],s=>[s.DateText,s.TimeText,s.Tests.ToString("N0",CultureInfo.CurrentCulture),s.Jobs.ToString("N0",CultureInfo.CurrentCulture),s.DigitizedBy,s.State]);
        _scheduleTable.SetItems(_scheduleRows);_scheduleTable.SelectedChanged+=async s=>await OpenSchedule(s.Id);
        _members=new("Pruebas del horario",[("JOB",145),("Prueba",190),("Laboratorio",105),("Fecha / hora",165),("Digitado por",150),("Ejecución",285),("Chequeo",165),("Original",250),("Tipo",130)],m=>[m.Item.Execution.Job,m.Item.Execution.PlanningTest,m.Item.Execution.Laboratory??"",m.Item.CheckedAtText,m.Item.Execution.DigitizedBy??"",m.Item.Execution.ExecutionId?.ToString()??"",m.Changed?"Cambió: revisar":_opened?.Schedule.State??"",m.Item.Execution.OriginalTest??"",m.Item.Execution.ExecutionType??""]);
        _review=Compact("Chequear horario",ReviewSchedule,true,()=>!_mutating&&_opened is{} d&&d.Schedule.Exceptions==0&&d.Schedule.ReviewedAt is null);
        var exceptions=Compact("Revisar excepciones",()=>{if(_opened is{} d){_members.SetItems(d.Members.Where(m=>m.Changed).ToArray());_detailMeta.Text=$"{d.Schedule.Exceptions:N0} pruebas cambiaron después de la digitación. Corrija y registre una nueva digitación antes de chequear.";}return Task.CompletedTask;});
        var history=Compact("Consultar historial",()=>{_history.Visibility=_history.Visibility==Visibility.Visible?Visibility.Collapsed:Visibility.Visible;return Task.CompletedTask;});
        var allMembers=Compact("Todas las pruebas",()=>{_members.SetItems(_opened?.Members);return Task.CompletedTask;});
        var close=Compact("Cerrar detalle",CloseSchedule);
        _history.Visibility=Visibility.Collapsed;
        var detailLayout=PlanningUi.Rows(GridLength.Auto,GridLength.Auto,new(1,GridUnitType.Star),GridLength.Auto,GridLength.Auto);detailLayout.RowSpacing=8;
        PlanningUi.Place(detailLayout,ConsultationVisuals.Split(_detailTitle,close),0);PlanningUi.Place(detailLayout,_detailMeta,1);PlanningUi.Place(detailLayout,_members,2);
        PlanningUi.Place(detailLayout,PlanningUi.Row(_review,exceptions,allMembers,history),3);PlanningUi.Place(detailLayout,new ScrollViewer{Content=_history,MaxHeight=100},4);
        _detail=new Border{Child=detailLayout,Padding=new(12),Background=PlanningUi.Brush("LimsSurfaceBrush"),BorderBrush=PlanningUi.Brush("LimsBorderBrush"),BorderThickness=new(1),CornerRadius=new(6),Visibility=Visibility.Collapsed,Height=330};
        _schedules=PlanningUi.Rows(new(1,GridUnitType.Star),GridLength.Auto);_schedules.RowSpacing=8;PlanningUi.Place(_schedules,_scheduleTable,0);PlanningUi.Place(_schedules,_detail,1);
        var closureTable=new ReportNativeTable<ReportClosure>("JOBs completamente digitados",[("JOB",190),("Pruebas requeridas",150),("Digitadas",110),("Última digitación",200),("Due Date",130)],c=>[c.Job,c.Required.ToString("N0",CultureInfo.CurrentCulture),c.Digitized.ToString("N0",CultureInfo.CurrentCulture),c.LastDigitizedAt.ToOffset(TimeSpan.FromHours(-6)).ToString("yyyy-MM-dd HH:mm",CultureInfo.InvariantCulture),c.DueDate?.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture)??""]);
        closureTable.SetItems(_closureRows);
        _closures=PlanningUi.Rows(GridLength.Auto,new(1,GridUnitType.Star));PlanningUi.Place(_closures,PlanningUi.Text("JOBs completos según las ejecuciones registradas. Cobertura TIPS no certificada; no constituye cierre oficial.",12,true),0);PlanningUi.Place(_closures,closureTable,1);
        var groupTools=PlanningUi.Row(Compact("Exportar chequeados",ExportSchedules));groupTools.Visibility=Visibility.Collapsed;
        _next=Compact("Cargar más",async()=>await LoadGroups(false));_next.Visibility=Visibility.Collapsed;
        var body=new Grid();body.Children.Add(_digitization);body.Children.Add(_schedules);body.Children.Add(_closures);
        var top=PlanningUi.Stack(header,_tabs,searchBar,groupTools,_result);top.Spacing=8;
        var layout=PlanningUi.Rows(GridLength.Auto,new(1,GridUnitType.Star),GridLength.Auto);layout.RowSpacing=8;
        PlanningUi.Place(layout,top,0);PlanningUi.Place(layout,body,1);PlanningUi.Place(layout,ConsultationVisuals.Split(PlanningUi.Row(_progress,_status),_next),2);Content=layout;
        void SetView(){var index=_tabs.SelectedIndex;_digitization.Visibility=index==0?Visibility.Visible:Visibility.Collapsed;_schedules.Visibility=index==1?Visibility.Visible:Visibility.Collapsed;_closures.Visibility=index==2?Visibility.Visible:Visibility.Collapsed;_view.Visibility=filters.Visibility=multiple.Visibility=index==0?Visibility.Visible:Visibility.Collapsed;_scheduleState.Visibility=groupTools.Visibility=index==1?Visibility.Visible:Visibility.Collapsed;_next.Visibility=index==0?Visibility.Collapsed:Visibility.Visible;}
        _tabs.SelectionChanged+=async(_,_)=>{SetView();Feedback(null);Motion.Enter(body,y:3,milliseconds:150);await Load();};SetView();
        _sync.Tick+=async(_,_)=>await Synchronize();Loaded+=(_,_)=>_sync.Start();Unloaded+=(_,_)=>{_sync.Stop();_request.Cancel();_detailRequest.Cancel();};
        Motion.ConfigureVisibility(_context);Motion.ConfigureVisibility(_result);Motion.ConfigureVisibility(_detail);
    }
    private static Button Compact(string title,Func<Task> action,bool primary=false,Func<bool>? enabledAfter=null)
    {var b=PlanningUi.Button(title,action,primary,enabledAfter);b.FontSize=12;b.MinHeight=34;b.Padding=new(10,5,10,5);return b;}
    private bool Has(string permission)=>_permissions().Contains(permission,StringComparer.Ordinal);
    private Task CloseSchedule(){_detailRequest.Cancel();_detail.Visibility=Visibility.Collapsed;_opened=null;return Task.CompletedTask;}
    private void Feedback(string? message){_result.Text=message??"";_result.Visibility=string.IsNullOrEmpty(message)?Visibility.Collapsed:Visibility.Visible;if(!string.IsNullOrEmpty(message))Motion.Enter(_result,y:2,milliseconds:140);}
    private void UpdateSelection()
    {
        var count=_grid.Selected.Count;_selection.Text=count==1?"1 prueba seleccionada":$"{count:N0} pruebas seleccionadas";_context.Visibility=count>0?Visibility.Visible:Visibility.Collapsed;
        _mark.Visibility=Has(PlanningPermissions.ReportMark)?Visibility.Visible:Visibility.Collapsed;_correct.Visibility=Has(PlanningPermissions.ReportReview)?Visibility.Visible:Visibility.Collapsed;
        _mark.IsEnabled=!_mutating&&count is >0 and <=500&&_grid.Selected.All(x=>!x.Execution.Complete&&!x.Execution.NoProgram&&!x.Execution.OnHold&&!string.IsNullOrWhiteSpace(x.Execution.Equivalence));_correct.IsEnabled=!_mutating&&_grid.Selected.Any(x=>x.Execution.Complete);_clockDate.IsEnabled=_clockTime.IsEnabled=!_mutating;
    }
    private void UpdateScanner()
    {
        _pause.Visibility=Has(PlanningPermissions.ReportMark)?Visibility.Visible:Visibility.Collapsed;_pause.IsEnabled=Has(PlanningPermissions.ReportMark)&&_trackingAvailable&&!_mutating;_pause.Content=_paused?"Captura AR":"Pausar captura AR";
        _scanRow.Visibility=Has(PlanningPermissions.ReportMark)&&_trackingAvailable&&!_paused?Visibility.Visible:Visibility.Collapsed;
    }
    private async Task Multiple()
    {
        var text=PlanningUi.Field("JOBs",max:20000);text.AcceptsReturn=true;text.Height=190;text.Width=420;text.PlaceholderText="Pegue JOBs desde Excel";AutomationProperties.SetName(text,"JOBs de búsqueda múltiple");var error=PlanningUi.Text("Hasta 500 JOBs únicos",12,true);
        var dialog=new ContentDialog{XamlRoot=XamlRoot,Style=(Style)Application.Current.Resources["LimsEditorDialogStyle"],Title="Búsqueda múltiple",Content=PlanningUi.Stack(text,error),PrimaryButtonText="Buscar JOBs",CloseButtonText="Cancelar"};
        dialog.PrimaryButtonClick+=(_,e)=>{try{PlanningJobList.Parse(text.Text);}catch(FormatException ex){error.Text=ex.Message;e.Cancel=true;}};
        if(await dialog.ShowAsync()!=ContentDialogResult.Primary)return;_search.Text=PlanningJobList.Parse(text.Text).Search;await Load();
    }
    public async Task Load()
    {
        if(_mutating)return;_request.Cancel();_request.Dispose();_request=new();_detailRequest.Cancel();_loading=true;var ct=_request.Token;_progress.IsActive=true;
        try
        {
            if(_tabs.SelectedIndex!=0){await LoadGroups(true);return;}
            var query=new ReportListQuery(_search.Text,_view.SelectedIndex switch{1=>"Checked",2=>"All",_=>"Pending"},_lab.Text,_test.Text,_service.Text,_buyer.Text,PageSize:500,Sort:_sort,Descending:_descending,VerifiedBy:_verified,Block:_block,CheckedDate:_date);
            var rows=new ReportListRows(async(page,revision,cancellation)=>{var response=await _api.ReportList(query with{Page=page,Revision=revision},cancellation);if(!response.IsSuccess||response.Value is null)throw new InvalidOperationException(response.Error??"No se pudo consultar Report List.");return response.Value;},ct);
            _connection.Text="Consultando…";_status.Text="Cargando ejecuciones…";
            rows.Updated+=error=>{if(ct.IsCancellationRequested)return;if(error is not null){_connection.Text="Sin respuesta";_status.Text=error.Message;return;}_connection.Text="API conectada";_status.Text=$"{rows.Count:N0} de {rows.Total:N0} ejecuciones · Selección temporal · Fecha y hora de Guatemala";_trackingAvailable=rows.Capabilities?.ScannerAvailable==true;UpdateScanner();};
            await rows.LoadNext();if(ct.IsCancellationRequested||rows.Revision is null)return;
            _rows=rows;_listRevision=rows.Revision;_grid.SetSort(_sort,_descending);_grid.SetFilters(new[]{string.IsNullOrEmpty(_search.Text)?"":"Job",string.IsNullOrEmpty(_test.Text)?"":"Test",string.IsNullOrEmpty(_lab.Text)?"":"Laboratory",string.IsNullOrEmpty(_buyer.Text)?"":"Buyer"});_grid.SetSource(rows);UpdateSelection();
        }
        catch(OperationCanceledException){}
        catch(Exception e){_connection.Text="Sin respuesta";Feedback(e.Message);}
        finally{if(!ct.IsCancellationRequested){_loading=false;_progress.IsActive=false;}}
    }
    private ReportScheduleQuery GroupQuery()=>new(_search.Text,_scheduleState.SelectedIndex switch{1=>"Pending",2=>"Reviewed",3=>"Exceptions",_=>"All"},_page,100,_page==1?null:_listRevision);
    private async Task LoadGroups(bool reset)
    {
        if(_mutating)return;var ct=_request.Token;_progress.IsActive=true;
        try
        {
            if(reset){_page=1;_detail.Visibility=Visibility.Collapsed;_opened=null;}
            if(_tabs.SelectedIndex==1){var response=await _api.ReportSchedules(GroupQuery(),ct);if(ct.IsCancellationRequested)return;if(!response.IsSuccess||response.Value is not {} data){Feedback(response.Error);return;}if(reset)_scheduleRows.Clear();foreach(var s in data.Items)_scheduleRows.Add(s);_total=data.Total;_listRevision=data.Revision;_status.Text=$"{_scheduleRows.Count:N0} de {_total:N0} horarios · Seleccione un horario para revisarlo";}
            else{var response=await _api.ReportClosures(GroupQuery() with{State="All"},ct);if(ct.IsCancellationRequested)return;if(!response.IsSuccess||response.Value is not {} data){Feedback(response.Error);return;}if(reset)_closureRows.Clear();foreach(var s in data.Items)_closureRows.Add(s);_total=data.Total;_listRevision=data.Revision;_status.Text=$"{_closureRows.Count:N0} de {_total:N0} JOBs completos entre registros disponibles";}
            _connection.Text="API conectada";_page++;_next.IsEnabled=(_tabs.SelectedIndex==1?_scheduleRows.Count:_closureRows.Count)<_total;
        }
        finally{_progress.IsActive=false;}
    }
    private async Task OpenSchedule(Guid id)
    {
        _detailRequest.Cancel();_detailRequest.Dispose();_detailRequest=new();var ct=_detailRequest.Token;
        try
        {
        var response=await _api.ReportSchedule(id,ct);if(ct.IsCancellationRequested)return;if(!response.IsSuccess||response.Value is not {} detail){Feedback(response.Error);return;}
        _opened=detail;_detailTitle.Text=$"{detail.Schedule.DateText} · {detail.Schedule.TimeText} · {detail.Schedule.Tests:N0} pruebas";
        _detailMeta.Text=$"Digitado por {detail.Schedule.DigitizedBy} · {detail.Schedule.State}"+(detail.Schedule.ReviewedBy is {} reviewer?$" · Revisado por {reviewer} · {detail.Schedule.ReviewedAt?.ToOffset(TimeSpan.FromHours(-6)):g}":"");
        _history.Text=string.Join('\n',detail.History.Select(h=>$"{h.At.ToOffset(TimeSpan.FromHours(-6)):yyyy-MM-dd HH:mm:ss} · {h.ActorName} · {PlanningStatusText.Action(h.Action)} · {h.Reason}"));_history.Visibility=Visibility.Collapsed;
        _members.SetItems(detail.Members);_review.Visibility=Has(PlanningPermissions.ReportReview)?Visibility.Visible:Visibility.Collapsed;_review.IsEnabled=detail.Schedule.Exceptions==0&&detail.Schedule.ReviewedAt is null&&!_mutating;
        _detail.Visibility=Visibility.Visible;Motion.Enter(_detail,y:4,milliseconds:150);
        }
        catch(OperationCanceledException)when(ct.IsCancellationRequested){ }
    }
    private async Task SaveDigitization()
    {
        if(_mutating||!OperationalTime(out var at))return;var selected=_grid.Selected.ToArray();if(!Has(PlanningPermissions.ReportMark)||selected.Length is <1 or >500||selected.Any(x=>x.Execution.Complete)){Feedback("Seleccione de 1 a 500 ejecuciones pendientes.");return;}
        _mutating=true;_grid.SetBusy(true);UpdateSelection();
        try
        {
            var reason=PlanningUi.Field("Motivo","Confirmación de digitación",1000);var admin=new CheckBox{Content="Excepción administrativa del modo de captura"};
            var items=PlanningUi.Text(string.Join('\n',selected.Select(x=>$"{x.Execution.Job} · {x.Execution.PlanningTest} · {x.Execution.OriginalTest}\n{x.Execution.ExecutionId}")),12);
            var content=PlanningUi.Stack(PlanningUi.Text($"{selected.Length:N0} pruebas · {at:yyyy-MM-dd HH:mm} · Guatemala",14),new ScrollViewer{Content=items,MaxHeight=230},reason);
            if(selected.GroupBy(x=>(x.Execution.Job,x.Execution.PlanningTest)).Any(g=>g.Count()>1))content.Children.Add(PlanningUi.Text("Hay pruebas repetidas. Cada ejecución se guardará por separado.",12,true));if(_administrator())content.Children.Add(admin);
            var dialog=new ContentDialog{XamlRoot=XamlRoot,Style=(Style)Application.Current.Resources["LimsEditorDialogStyle"],Title="Confirmar digitación",Content=content,PrimaryButtonText="Confirmar y guardar",CloseButtonText="Cancelar",DefaultButton=ContentDialogButton.Close};dialog.PrimaryButtonClick+=(_,e)=>e.Cancel=string.IsNullOrWhiteSpace(reason.Text);
            if(await dialog.ShowAsync()!=ContentDialogResult.Primary)return;
            var versions=selected.Select(x=>new ReportExecutionVersion(x.Execution.ExecutionId!.Value,x.Version)).OrderBy(x=>x.ExecutionId).ToArray();
            if(_retry is null||_retry.OperationalAt!=at||_retry.Reason!=reason.Text||_retry.AdminOverride!=(admin.IsChecked==true)||!_retry.Executions.SequenceEqual(versions))_retry=new(Guid.NewGuid(),versions,at,reason.Text,admin.IsChecked==true);
            var response=await _api.DigitizeReport(_retry,_request.Token);if(!response.IsSuccess){Feedback(response.Error);return;}_retry=null;Feedback($"{selected.Length:N0} pruebas digitadas. Horario disponible para chequeo.");_grid.ClearSelection();if(Changed is{} changed)await changed();
        }
        finally{_mutating=false;_grid.SetBusy(false);UpdateSelection();UpdateScanner();}
        await Load();
    }
    private async Task ReviewSchedule()
    {
        if(_mutating||!Has(PlanningPermissions.ReportReview)||_opened is not {} detail)return;_mutating=true;_review.IsEnabled=false;
        try
        {
            if(!await PlanningUi.Confirm(XamlRoot,"Chequear horario",$"Confirmar revisión de las {detail.Schedule.Tests:N0} pruebas de {detail.Schedule.DateText} a las {detail.Schedule.TimeText}."))return;
            var response=await _api.ReviewSchedule(new(detail.Schedule.Id,detail.Schedule.Version,detail.Members.Select(m=>new ReportExecutionVersion(m.Item.Execution.ExecutionId!.Value,m.Item.Version)).ToArray(),"Revisión completa del horario"),_request.Token);
            if(!response.IsSuccess){Feedback(response.Error);await OpenSchedule(detail.Schedule.Id);return;}
            Feedback("Horario chequeado y guardado en el historial.");if(Changed is{} changed)await changed();var index=_scheduleRows.ToList().FindIndex(x=>x.Id==detail.Schedule.Id);if(index>=0&&response.Value is{} saved)_scheduleRows[index]=saved;await OpenSchedule(detail.Schedule.Id);
        }
        finally{_mutating=false;if(_opened is{} d)_review.IsEnabled=d.Schedule.Exceptions==0&&d.Schedule.ReviewedAt is null;}
    }
    private async Task ExportSchedules()
    {
        var result=await _api.ExportSchedules(GroupQuery() with{Page=1,Revision=null},_request.Token);if(!result.IsSuccess||result.Value is null){Feedback(result.Error);return;}var path=await PlanningUi.PickFile(XamlRoot,true,"Horarios chequeados");if(path is null)return;await System.IO.File.WriteAllBytesAsync(path,result.Value);Feedback("Chequeados exportados.");
    }
    private async Task Correct()
    {
        if(_mutating||!Has(PlanningPermissions.ReportReview))return;var selected=_grid.Selected.Where(x=>x.Execution.Complete).ToArray();if(selected.Length is <1 or >500)return;_mutating=true;_grid.SetBusy(true);UpdateSelection();
        try
        {
            var reason=PlanningUi.Field("Motivo obligatorio",max:1000);var admin=new CheckBox{Content="Excepción administrativa del modo de captura"};var content=PlanningUi.Stack(PlanningUi.Text("La corrección restaura pruebas pendientes e invalida el chequeo de su horario.",13,true),reason);if(_administrator())content.Children.Add(admin);
            var dialog=new ContentDialog{XamlRoot=XamlRoot,Title=$"Corregir {selected.Length} digitaciones",Content=content,PrimaryButtonText="Guardar corrección",CloseButtonText="Cancelar"};dialog.PrimaryButtonClick+=(_,e)=>e.Cancel=string.IsNullOrWhiteSpace(reason.Text);if(await dialog.ShowAsync()!=ContentDialogResult.Primary)return;
            var response=await _api.CheckReport(new(selected.Select(x=>new ReportExecutionVersion(x.Execution.ExecutionId!.Value,x.Version)).ToArray(),false,reason.Text,admin.IsChecked==true),true,_request.Token);Feedback(response.IsSuccess?"Corrección guardada. Revise el horario anterior.":response.Error);if(response.IsSuccess&&Changed is{} changed)await changed();
        }
        finally{_mutating=false;_grid.SetBusy(false);UpdateSelection();}await Load();
    }
    private async Task Keep(ReportListItem item)
    {
        if(_mutating||!Has(PlanningPermissions.ReportReview))return;_mutating=true;_grid.SetBusy(true);
        try
        {
            var keep=new CheckBox{Content="Mantener en programación",IsChecked=item.KeepInPlanning};var reason=PlanningUi.Field("Motivo obligatorio",max:1000);var dialog=new ContentDialog{XamlRoot=XamlRoot,Title=item.Execution.Job+" · "+item.Execution.PlanningTest,Content=PlanningUi.Stack(keep,reason),PrimaryButtonText="Guardar permanencia",CloseButtonText="Cancelar"};dialog.PrimaryButtonClick+=(_,e)=>e.Cancel=string.IsNullOrWhiteSpace(reason.Text);if(await dialog.ShowAsync()!=ContentDialogResult.Primary)return;
            var response=await _api.KeepReport(new(new(item.Execution.ExecutionId!.Value,item.Version),keep.IsChecked==true,reason.Text),_request.Token);Feedback(response.IsSuccess?"Permanencia guardada.":response.Error);if(response.IsSuccess&&Changed is{} changed)await changed();
        }
        finally{_mutating=false;_grid.SetBusy(false);UpdateSelection();}await Load();
    }
    private async Task Scan()
    {
        if(_mutating||_paused||!_trackingAvailable||!Has(PlanningPermissions.ReportMark)||!OperationalTime(out var at))return;_mutating=true;_grid.SetBusy(true);UpdateScanner();
        try{var response=await _api.ScanReport(new(_scan.Text,"Digitación mediante código AR",at),_request.Token);Feedback(response.IsSuccess?"Código verificado y ejecución digitada.":response.Error);if(response.IsSuccess){_scan.Text="";if(Changed is{} changed)await changed();}}
        finally{_mutating=false;_grid.SetBusy(false);UpdateScanner();}await Load();
    }
    private bool OperationalTime(out DateTimeOffset value)
    {
        value=default;if(!DateTime.TryParseExact(_clockDate.Text+" "+_clockTime.Text,"yyyy-MM-dd HH:mm",CultureInfo.InvariantCulture,DateTimeStyles.None,out var local)){Feedback("Revise fecha y hora: yyyy-MM-dd y HH:mm.");return false;}value=new DateTimeOffset(DateTime.SpecifyKind(local,DateTimeKind.Unspecified),TimeSpan.FromHours(-6));return true;
    }
    private void ColumnFilter(string key,FrameworkElement anchor)
    {
        var value=key switch{"Job"=>_search.Text,"Test"=>_test.Text,"Laboratory"=>_lab.Text,"Buyer"=>_buyer.Text,"VerifiedBy"=>_verified,"Block"=>_block?.ToString(CultureInfo.InvariantCulture),"Date"=>_date?.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture),_=>""};var field=PlanningUi.Field(key=="Date"?"Fecha · yyyy-MM-dd":"Contiene",value);field.Width=255;var error=PlanningUi.Text("",12,true);var panel=PlanningUi.Stack(field,error);var flyout=new Flyout{Content=panel};
        async Task Apply(){if(key=="Block"&&!string.IsNullOrWhiteSpace(field.Text)&&(!long.TryParse(field.Text,out var n)||n<1)){error.Text="Escriba el bloque histórico.";return;}if(key=="Date"&&!string.IsNullOrWhiteSpace(field.Text)&&!DateOnly.TryParseExact(field.Text,"yyyy-MM-dd",out _)){error.Text="Use yyyy-MM-dd.";return;}switch(key){case "Job":_search.Text=field.Text;break;case "Test":_test.Text=field.Text;break;case "Laboratory":_lab.Text=field.Text;break;case "Buyer":_buyer.Text=field.Text;break;case "VerifiedBy":_verified=field.Text;break;case "Block":_block=long.TryParse(field.Text,out var b)?b:null;break;case "Date":_date=DateOnly.TryParseExact(field.Text,"yyyy-MM-dd",out var d)?d:null;break;}flyout.Hide();await Load();}
        panel.Children.Add(Compact("Aplicar columna",Apply));panel.Children.Add(Compact("Quitar filtro",async()=>{field.Text="";await Apply();}));field.KeyDown+=async(_,e)=>{if(e.Key==VirtualKey.Enter){e.Handled=true;await Apply();}};flyout.ShowAt(anchor);
    }
    private async Task Synchronize()
    {
        if(_loading||_mutating||!IsLoaded)return;
        try{var result=await _api.ReportList(new(PageSize:1),_request.Token);var current=_tabs.SelectedIndex==0?_rows?.Revision:_listRevision;if(!result.IsSuccess||result.Value is null){_connection.Text="Sin respuesta";return;}_connection.Text="API conectada";if(current==result.Value.Revision)return;if(_grid.Selected.Count>0||_opened is not null)Feedback("Hay cambios de otro usuario. Actualice antes de confirmar; su selección se conserva.");else await Load();}
        catch(OperationCanceledException){}
    }
    public void Clear(){_sync.Stop();_request.Cancel();_detailRequest.Cancel();_grid.SetSource(null);_rows=null;_search.Text="";_scan.Text="";_scheduleRows.Clear();_closureRows.Clear();_opened=null;_retry=null;Feedback(null);}
    public void Dispose(){Clear();_request.Dispose();_detailRequest.Dispose();}
}
