REPORT LIST - ACTUALIZACION DEL SERVIDOR EXISTENTE

Diagnostico del 19 de noviembre de 2026:
- Cliente Production configurado para http://10.226.248.191:8080/.
- GET /health/ready: 200.
- GET /api/planning/jobs: 401 sin sesion, ruta publicada.
- GET /api/planning/report-list: 404 sin sesion, ruta ausente.
- La salida local usada por WinAppCLI era bin/Debug/.../win-x64, del 18-Nov.
- La compilacion previa validada estaba en bin/x64/Debug/.../win-x64.

Contenido revisable:
- api/: publicacion Release de la misma Lims.Api, con Report List integrado.
- sql/preflight-execution-report-list.sql: solo lectura, no cambia datos.
- sql/upgrade-execution-report-list.sql: migracion aditiva y transaccional.
- schema-reference/: codigo de las migraciones y esquema previo de identidad.
- manifest.json: SHA256 por archivo incluido.

NO SE HA ACTUALIZADO EL SERVIDOR NI SU BASE DE DATOS.
Este paquete no contiene configuracion, claves JWT ni credenciales.

Antes de desplegar:
1. Identificar el servicio/directorio real de la API y su configuracion efectiva.
2. Confirmar la base de Planning: ConnectionStrings:Planning o, si no existe,
   ConnectionStrings:Lims. No inferirla de la configuracion de desarrollo local.
3. Ejecutar el preflight en modo lectura sobre ese destino y revisar resultados.
4. Si falta SeparatePlanningIdentity, preparar esa actualizacion con las conexiones
   correctas de identidad y Planning antes de la migracion nueva. No ejecutar un
   instalador inicial sobre un esquema existente.
5. Con autorizacion para ese entorno, respaldar los binarios y el destino de
   Planning; aplicar la migracion aditiva en la base aprobada; reemplazar los
   binarios de la misma API conservando sus appsettings, variables y secretos.
6. Reiniciar el servicio existente y comprobar las rutas y sus permisos.
7. Repetir la aceptacion autenticada con datos del entorno, sin trasladar los
   marcados ni los datos ficticios de la validacion local.

Si alguna comprobacion falla, no continuar con la publicacion ni modificar tablas.